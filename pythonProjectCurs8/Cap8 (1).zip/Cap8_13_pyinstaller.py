"""
813 Module
Modulul pyinstaller - exemple
PF - 29.06.2021 v6
"""  #

# PyInstaller poate fi utilizat pentru Windows, Mac OS X, and Linux.
# documentatie https://pyinstaller.readthedocs.io/en/v3.5/

"""
   1.     pyinstaller myscript.py                                   - creaza un director "dist" cu fisierele
        sau 
   2.     pyinstaller "C:\\Documents and Settings\\project\\myscript.py"

   3.     pyinstaller --onefile myscript.py                         - creaza un singur fisier .exe
"""